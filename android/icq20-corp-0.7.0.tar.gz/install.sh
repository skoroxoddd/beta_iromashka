#!/bin/bash
set -e

echo ""
echo "┌────────────────────────────────────────┐"
echo "│   🌼 АйРомашка — Корпоративная нода    │"
echo "│          Installer v0.7.0              │"
echo "└────────────────────────────────────────┘"
echo ""

# Check root
if [ "$(id -u)" -ne 0 ]; then
    echo "❌ Запустите от root: sudo bash install.sh"
    exit 1
fi

# Check architecture
ARCH="$(uname -m)"
if [[ "$ARCH" != "x86_64" && "$ARCH" != "aarch64" ]]; then
    echo "❌ Поддерживаются только x86_64 и aarch64"
    exit 1
fi

INSTALL_DIR="/opt/icq20-corp"
DATA_DIR="/opt/icq20-corp/data"

echo "📦 Установка в $INSTALL_DIR ..."

# ── 0. Stop old version if running ──
systemctl stop icq20-corp 2>/dev/null || true

# ── 1. Install system dependencies ──
echo ""
echo "📋 Установка зависимостей..."
apt-get update -qq > /dev/null 2>&1
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    postgresql postgresql-contrib curl ca-certificates \
    libssl3 libssl-dev pkg-config net-tools ufw > /dev/null 2>&1
echo "✅ Системные зависимости установлены"

# ── 2. Setup PostgreSQL ──
echo ""
echo "🐘 Настройка PostgreSQL..."
if ! systemctl is-active --quiet postgresql; then
    systemctl enable postgresql 2>/dev/null || true
    sleep 3
fi

su - postgres -c "psql -c \"SELECT 1 FROM pg_roles WHERE rolname='icq20corp'\" | grep -q 1 || psql -c \"CREATE ROLE icq20corp LOGIN PASSWORD 'corp_db_pass_2026';\""
su - postgres -c "psql -c \"SELECT 1 FROM pg_database WHERE datname='icq20corp'\" | grep -q 1 || psql -c \"CREATE DATABASE icq20corp OWNER icq20corp;\""

mkdir -p "$DATA_DIR" 2>/dev/null
echo "✅ PostgreSQL настроен"

# ── 3. Install Caddy ──
echo ""
echo "🔒 Установка Caddy..."
if ! command -v caddy &>/dev/null; then
    caddy_repo=$(curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/gpg.key)
    echo "${caddy_repo}" | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null || true
    echo "deb [signed-by=/usr/share/keyrings/caddy-stable-archive-keyring.gpg] https://dl.cloudsmith.io/public/caddy/stable/deb/debian any-version main" > /etc/apt/sources.list.d/caddy-stable.list 2>/dev/null || true
    # Try direct install
    if command -v apt-get &>/dev/null; then
        apt-get update -qq > /dev/null 2>&1 || true
        DEBIAN_FRONTEND=noninteractive apt-get install -y -qq caddy > /dev/null 2>&1 || {
            echo "⚠️ Caddy не установлен из репозитория. Скачиваю бинарник..."
            curl -fsSL "https://github.com/caddyserver/caddy/releases/download/v2.9.1/caddy_2.9.1_linux_${ARCH}.tar.gz" | tar xz -C /tmp 2>/dev/null
            if [ -f /tmp/caddy ]; then
                mv /tmp/caddy /usr/local/bin/caddy
                chmod +x /usr/local/bin/caddy
                echo "✅ Caddy установлен как бинарник"
            fi
        }
    fi
else
    echo "✅ Caddy уже установлен"
fi

# ── 4. Create directories ──
echo ""
echo "📁 Создание директорий..."
mkdir -p "$INSTALL_DIR/bin"
mkdir -p "$INSTALL_DIR/www"
mkdir -p "$INSTALL_DIR/backups"
chmod +x "$INSTALL_DIR/bin/icq2_core" 2>/dev/null
echo "✅ Директории созданы"

# ── 5. Configure Caddy ──
read -rp "🌐 Домен (или Enter для без TLS): " DOMAIN
if [ -z "$DOMAIN" ]; then
    echo "⚠️ Без TLS - доступ по HTTP://localhost:8080"
    DOMAIN=""
else
    echo "📝 Caddy настроен для: $DOMAIN"
fi

read -rp "🏢 Название компании: " CORP_NAME
[ -z "$CORP_NAME" ] && CORP_NAME="Корпоративный портал"

read -rp "🎨 Бренд-цвет (напр. #1B3A6B, или Enter): " CORP_COLOR
[ -z "$CORP_COLOR" ] && CORP_COLOR="#1B3A6B"

read -rp "🔐 JWT Secret (Enter = сгенерировать): " JWT_SECRET
[ -z "$JWT_SECRET" ] && JWT_SECRET=$(openssl rand -hex 64)

read -rp "🔑 GRPC Shared Secret (Enter = сгенерировать): " GRPC_SECRET
[ -z "$GRPC_SECRET" ] && GRPC_SECRET=$(openssl rand -hex 32)

read -rp "📡 Адрес основной ноды (напр. nodes.72.56.11.228:50051, или Enter): " PEERS
[ -z "$PEERS" ] && PEERS=""

read -rp "📡 Адрес этой ноды (напр. 0.0.0.0:50051): " NODE_ADDR
[ -z "$NODE_ADDR" ] && NODE_ADDR="0.0.0.0:50051"

read -rp "🆔 NODE_ID (напр. corp1): " NODE_ID
[ -z "$NODE_ID" ] && NODE_ID="corp1"

# Generate .env
cat > "$INSTALL_DIR/.env" << EOF
DATABASE_URL=postgresql://icq20corp:corp_db_pass_2026@127.0.0.1:5432/icq20corp
JWT_SECRET=$JWT_SECRET
JWT_ISSUER=icq20-corp
NODE_ID=$NODE_ID
NODE_ADDR=$NODE_ADDR
PEERS=$PEERS
GRPC_SHARED_SECRET=$GRPC_SECRET
CORP_NAME=$CORP_NAME
CORP_COLOR=$CORP_COLOR
CORP_NODE=true
FCM_SERVICE_ACCOUNT=
EOF

chmod 600 "$INSTALL_DIR/.env"
echo "✅ .env создан"

# Generate Caddyfile
if [ -n "$DOMAIN" ]; then
    cat > "/etc/caddy/Caddyfile" << CADDYEOF
$DOMAIN {
    log {
        output file /var/log/caddy/corp-access.log { roll_size 10mb roll_keep 5 }
        format json
    }
    header {
        Access-Control-Allow-Origin "*"
        Access-Control-Allow-Methods "GET, POST, OPTIONS, DELETE, PUT"
        Access-Control-Allow-Headers "Content-Type, Authorization"
    }
    handle /api/* {
        reverse_proxy 127.0.0.1:8080
    }
    handle /chat {
        reverse_proxy 127.0.0.1:8080 {
            flush_interval -1
            transport http { read_timeout 0 write_timeout 0 }
        }
    }
    handle {
        root * /opt/icq20-corp/www
        try_files {path} /index.html
        file_server
    }
}
CADDYEOF
    systemctl restart caddy 2>/dev/null || true
else
    echo "# No domain - HTTP only" > /etc/caddy/Caddyfile
fi

# ── 6. Install web files ──
if [ -f "www/index.html" ]; then
    cp -r www/* "$INSTALL_DIR/www/" 2>/dev/null
elif [ -f "www/index.html" ]; then
    echo "📝 Скопируйте файлы сайта вручную в $INSTALL_DIR/www/"
fi

# ── 7. Install systemd service ──
cat > /etc/systemd/system/icq20-corp.service << SVCEOF
[Unit]
Description=ICQ 2.0 Corporate Node ($CORP_NAME)
After=network.target postgresql.service

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$INSTALL_DIR/.env
ExecStart=$INSTALL_DIR/bin/icq2_core
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable icq20-corp
echo "✅ systemd сервис: icq20-corp"

# ── 8. Firewall ──
echo ""
read -rp "🔥 Открыть порты 80 и 443 в ufw? (y/n): " OPEN_FW
if [[ "$OPEN_FW" == "y" ]]; then
    ufw allow 80,443/tcp > /dev/null 2>&1 && echo "✅ Порты 80/443 открыты"
    ufw allow 22/tcp > /dev/null 2>&1 || true
    ufw --force enable > /dev/null 2>&1 || true
fi

# ── 9. Start ──
echo ""
echo "🚀 Запуск корпоративной ноды..."
systemctl start icq20-corp
sleep 2
systemctl is-active icq20-corp > /dev/null 2>&1 && STATUS="✅ работает" || STATUS="⚠️ ошибка"

echo ""
echo "┌─────────────────────────────────────┐"
echo "│   🎉 Установка завершена!           │"
echo "│                                     │"
echo "│   NODE_ID: $NODE_ID                "
echo "│   NODE_ADDR: $NODE_ADDR              "
echo "│   Status: $STATUS          "
[ -n "$DOMAIN" ] && echo "│   URL: https://$DOMAIN           "
echo "│                                     "
echo "│   Лог:   journalctl -u icq20-corp   │"
echo "│   Конфиг: $INSTALL_DIR/.env          "
echo "│   Бэкап: $INSTALL_DIR/backups/       "
echo "└─────────────────────────────────────┘"
echo ""
echo "📝 Добавьте корпоративные UINы:"
echo "   su - postgres -c \"psql -d icq20corp -c \\\"INSERT INTO corp_uin_map (uin, node_id) VALUES (1001, '$NODE_ID')\\\"\""
echo ""
echo "🔗 На основной ноде добавьте эту как peer:"
echo "   PEERS=$NODE_ADDR"
echo ""
echo "💾 Бэкап: $0 backup"
echo "🔍 Статус: journalctl -u icq20-corp -f"
echo ""
