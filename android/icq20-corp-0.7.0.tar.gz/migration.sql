-- Corp node SQL migration
-- Run on main node and corp nodes

-- White list: which UIN goes to which node
CREATE TABLE IF NOT EXISTS corp_uin_map (
    uin     BIGINT PRIMARY KEY,
    node_id TEXT NOT NULL DEFAULT '',
    added_at TIMESTAMPTZ DEFAULT NOW(),
    active  BOOL NOT NULL DEFAULT TRUE
);

-- Corp branding info (per-node)
CREATE TABLE IF NOT EXISTS corp_branding (
    node_id    TEXT PRIMARY KEY,
    name        TEXT NOT NULL DEFAULT '',
    logo_url    TEXT NOT NULL DEFAULT '',
    theme_color TEXT NOT NULL DEFAULT '#1B3A6B'
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_corp_uin_active ON corp_uin_map (node_id, active) WHERE active = TRUE;
