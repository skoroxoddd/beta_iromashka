#!/bin/bash
set -e
NOW=$(date +"%Y%m%d_%H%M")
BACKUP_DIR="/opt/icq20-corp/backups"
mkdir -p "$BACKUP_DIR"

echo "💾 Бэкап корпоративной ноды..."

# DB
su - postgres -c "pg_dump -d icq20corp -f ${BACKUP_DIR}/icq20corp_${NOW}.sql"
gzip "${BACKUP_DIR}/icq20corp_${NOW}.sql"
echo "✅ БД: ${BACKUP_DIR}/icq20corp_${NOW}.sql.gz"

# Config
tar czf "${BACKUP_DIR}/config_${NOW}.tar.gz" /opt/icq20-corp/.env /etc/caddy/Caddyfile 2>/dev/null || true
echo "✅ Конфиг: ${BACKUP_DIR}/config_${NOW}.tar.gz"

# Keep last 10 backups
ls -t ${BACKUP_DIR}/icq20corp_*.sql.gz 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true
ls -t ${BACKUP_DIR}/config_*.tar.gz 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true

echo "📁 Все:"
ls -lh "$BACKUP_DIR"
